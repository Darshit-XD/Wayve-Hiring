---
name: Wayve 3D visual system
description: The Wayve marketplace uses lightweight CSS 3D primitives for interactive product visuals.
---

Wayve's premium 3D treatment should prefer CSS 3D primitives and DOM/SVG composition over downloaded WebGL models when the visual goal can be met without a renderer.

**Why:** This preserves fast loading, responsive behavior, reduced-motion support, and a static fallback on devices that cannot handle WebGL while keeping the existing brand and layout stable.

**How to apply:** Keep future 3D additions additive, GPU-friendly, and pointer/scroll driven; introduce Three.js or React Three Fiber only when a real mesh or renderer capability is required.