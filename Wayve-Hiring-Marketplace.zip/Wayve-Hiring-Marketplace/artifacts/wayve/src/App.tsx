import { type PointerEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  BadgeCheck,
  Bell,
  BookOpen,
  Bookmark,
  BookmarkCheck,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  Clock3,
  Compass,
  Eye,
  FileText,
  Heart,
  LayoutDashboard,
  LineChart,
  LogIn,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  PenLine,
  Search,
  Send,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  TrendingUp,
  UserRound,
  Users,
  WalletCards,
  X,
  Zap,
  GraduationCap,
  Rocket,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Link, Route, Switch, useLocation, useParams, Router as WouterRouter } from 'wouter';

type StyleKey = 'aurora' | 'editorial' | 'trusted-career' | 'creator-marketplace';
type StyleLandingKey = 'aurora-glass' | 'editorial' | 'trusted-career' | 'creator-marketplace';

const queryClient = new QueryClient();

const styleInfo: Record<StyleKey, { label: string; route: string; descriptor: string }> = {
  aurora: { label: 'Aurora Glass', route: '/style/aurora-glass', descriptor: 'Soft focus, sharp opportunity.' },
  editorial: { label: 'Editorial', route: '/style/editorial', descriptor: 'A point of view for every path.' },
  'trusted-career': { label: 'Trusted Career', route: '/style/trusted-career', descriptor: 'Confidence you can act on.' },
  'creator-marketplace': { label: 'Creator Marketplace', route: '/style/creator-marketplace', descriptor: 'Make your next move visible.' },
};

const jobs = [
  { id: 'j1', title: 'Senior Product Designer', company: 'Pollen Studio', location: 'Remote · Europe', type: 'Full-time', salary: '$108k – $132k', skills: ['Figma', 'Systems', 'Research'], postedAt: '2h ago' },
  { id: 'j2', title: 'Growth Marketing Lead', company: 'Northstar Health', location: 'New York, NY', type: 'Full-time', salary: '$96k – $118k', skills: ['Lifecycle', 'Strategy', 'B2B'], postedAt: '5h ago' },
  { id: 'j3', title: 'Front-end Engineer', company: 'Morrow Labs', location: 'Remote · Americas', type: 'Contract', salary: '$85 – $110/hr', skills: ['React', 'TypeScript', 'Motion'], postedAt: 'Yesterday' },
  { id: 'j4', title: 'Operations Coordinator', company: 'Common Thread', location: 'Austin, TX', type: 'Part-time', salary: '$32 – $40/hr', skills: ['Notion', 'Events', 'Ops'], postedAt: 'Yesterday' },
  { id: 'j5', title: 'Brand Copywriter', company: 'Oddbird Foods', location: 'Remote · Worldwide', type: 'Contract', salary: '$70 – $90/hr', skills: ['Voice', 'Campaigns', 'Editorial'], postedAt: '2 days ago' },
];
const talent = [
  { id: 't1', name: 'Maya Chen', role: 'Product designer', location: 'Brooklyn, NY', skills: ['Product strategy', 'UX systems', 'Figma'], rate: '$92/hr', availability: 'Available in 2 weeks', verified: true },
  { id: 't2', name: 'Jon Bell', role: 'Full-stack engineer', location: 'Lisbon, Portugal', skills: ['React', 'Node', 'AI products'], rate: '$105/hr', availability: 'Available now', verified: true },
  { id: 't3', name: 'Amina Okafor', role: 'Brand strategist', location: 'London, UK', skills: ['Positioning', 'Research', 'Narrative'], rate: '$78/hr', availability: 'Available now', verified: true },
  { id: 't4', name: 'Eli Romero', role: 'Motion designer', location: 'Los Angeles, CA', skills: ['3D', 'Art direction', 'Cinema 4D'], rate: '$88/hr', availability: 'Available in 1 week', verified: false },
  { id: 't5', name: 'Rhea Kapoor', role: 'Math tutor', location: 'Toronto, Canada', skills: ['Calculus', 'SAT prep', 'Teaching'], rate: '$48/hr', availability: 'Available now', verified: true },
  { id: 't6', name: 'Tomás Silva', role: 'Data analyst', location: 'Porto, Portugal', skills: ['SQL', 'Dashboards', 'Python'], rate: '$64/hr', availability: 'Available in 3 weeks', verified: true },
];
const services = [
  { id: 's1', provider: 'Maya Chen', category: 'Design', title: 'Product audit & a clear 30-day roadmap', price: '$680', rating: '4.9', deliveryTime: '5 days' },
  { id: 's2', provider: 'Rhea Kapoor', category: 'Tutoring', title: 'Calculus confidence, one concept at a time', price: '$48', rating: '5.0', deliveryTime: 'Flexible' },
  { id: 's3', provider: 'Eli Romero', category: 'Creative', title: 'A looping launch animation for your next drop', price: '$420', rating: '4.8', deliveryTime: '7 days' },
  { id: 's4', provider: 'Amina Okafor', category: 'Strategy', title: 'Find the words your customers repeat', price: '$950', rating: '4.9', deliveryTime: '10 days' },
  { id: 's5', provider: 'Jon Bell', category: 'Development', title: 'Build a working prototype in a week', price: '$1,800', rating: '4.7', deliveryTime: '7 days' },
  { id: 's6', provider: 'Tomás Silva', category: 'Data', title: 'Turn your messy metrics into a useful view', price: '$540', rating: '4.9', deliveryTime: '5 days' },
];

function useToastMessage() {
  const [message, setMessage] = useState('');
  const notify = (next: string) => {
    setMessage(next);
    window.setTimeout(() => setMessage(''), 2600);
  };
  return { message, notify };
}

function Toast({ message }: { message: string }) {
  if (!message) return null;
  return <div className="toast" role="status" data-testid="status-toast">{message}</div>;
}

function RevealSection({ children, className = '' }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (typeof IntersectionObserver === 'undefined') {
      setVisible(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.14, rootMargin: '0px 0px -7% 0px' },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return <section ref={ref} className={`${className} reveal-section ${visible ? 'is-visible' : ''}`}>{children}</section>;
}

function EmberField() {
  const embers = [
    [12, 28, 0], [24, 67, 1], [39, 22, 2], [53, 74, 1], [67, 31, 0],
    [78, 65, 2], [88, 42, 1], [18, 84, 2], [47, 44, 0], [72, 83, 1],
  ];
  return (
    <div className="ember-field" aria-hidden="true">
      {embers.map(([left, top, variant], index) => (
        <span
          className={`ember ember-${variant}`}
          key={`${left}-${top}`}
          style={{ left: `${left}%`, top: `${top}%`, animationDelay: `${index * -0.7}s` }}
        />
      ))}
    </div>
  );
}

function SceneProfileCard({ className, name, role, skills, availability }: { className: string; name: string; role: string; skills: string[]; availability: string }) {
  return (
    <div className={`scene-profile-card ${className}`} aria-label={`${name}, ${role}, ${availability}`}>
      <div className="scene-profile-top"><span className="scene-portrait">{name.split(' ').map((part) => part[0]).join('')}</span><span className="scene-availability"><span className="status-dot" />{availability}</span></div>
      <strong>{name}</strong>
      <small>{role}</small>
      <div className="scene-profile-skills">{skills.map((skill) => <span key={skill}>{skill}</span>)}</div>
    </div>
  );
}

function Wayve3DScene() {
  return (
    <div className="scene-3d" aria-hidden="true">
      <div className="scene-glow scene-glow-one" />
      <div className="scene-glow scene-glow-two" />
      <div className="scene-orb scene-orb-one" />
      <div className="scene-orb scene-orb-two" />
      <div className="scene-ribbon scene-ribbon-one" />
      <div className="scene-ribbon scene-ribbon-two" />
      <svg className="scene-network" viewBox="0 0 500 420" fill="none">
        <path d="M72 180L176 86L314 132L427 72M176 86L242 278L314 132L386 302M242 278L128 350L386 302L427 72" stroke="currentColor" strokeWidth="1" strokeDasharray="4 7" opacity=".58" />
        <circle cx="72" cy="180" r="7" fill="currentColor" /><circle cx="176" cy="86" r="6" fill="currentColor" />
        <circle cx="314" cy="132" r="8" fill="currentColor" /><circle cx="427" cy="72" r="5" fill="currentColor" />
        <circle cx="242" cy="278" r="8" fill="currentColor" /><circle cx="386" cy="302" r="6" fill="currentColor" />
        <circle cx="128" cy="350" r="5" fill="currentColor" />
      </svg>
      <SceneProfileCard className="scene-profile-one" name="Maya Chen" role="Product designer" skills={['Strategy', 'Figma']} availability="open now" />
      <SceneProfileCard className="scene-profile-two" name="Jon Bell" role="Full-stack engineer" skills={['React', 'AI']} availability="in 2 weeks" />
      <div className="scene-laptop">
        <div className="laptop-screen">
          <div className="laptop-camera" />
          <div className="laptop-ui-bar"><span /><span /><span /></div>
          <div className="laptop-ui">
            <div className="laptop-ui-sidebar"><i /><i /><i /><i /></div>
            <div className="laptop-ui-main">
              <div className="laptop-ui-heading"><b>Hiring dashboard</b><em>03 new</em></div>
              <div className="laptop-ui-chart"><span /><span /><span /><span /><span /></div>
              <div className="laptop-ui-rows"><div><span className="laptop-ui-avatar">MC</span><span>Product designer</span><b>92%</b></div><div><span className="laptop-ui-avatar alt">JB</span><span>Engineer</span><b>86%</b></div></div>
            </div>
          </div>
        </div>
        <div className="laptop-base"><span /><span /><span /></div>
      </div>
      <div className="scene-cube scene-cube-one" />
      <div className="scene-cube scene-cube-two" />
    </div>
  );
}

function Section3DObject({ kind }: { kind: 'briefcase' | 'learning' }) {
  if (kind === 'briefcase') {
    return <div className="section-3d-object object-briefcase" aria-hidden="true"><div className="briefcase-handle" /><div className="briefcase-body"><BriefcaseBusiness size={25} /><span /></div></div>;
  }
  return <div className="section-3d-object object-learning" aria-hidden="true"><div className="learning-cap"><GraduationCap size={38} /></div><div className="learning-book book-one" /><div className="learning-book book-two" /></div>;
}

function CareerGrowthObject() {
  return <div className="career-growth-object" aria-hidden="true"><div className="growth-orbit growth-orbit-one" /><div className="growth-orbit growth-orbit-two" /><div className="growth-rocket"><Rocket size={31} /></div><div className="growth-trail" /></div>;
}

function Logo() {
  return <Link href="/" className="brand" data-testid="link-wayve-logo"><span className="brand-mark">W</span><span>wayve</span></Link>;
}

function styleFromPath(path: string): StyleKey {
  if (path.includes('editorial')) return 'editorial';
  if (path.includes('trusted-career')) return 'trusted-career';
  if (path.includes('creator-marketplace')) return 'creator-marketplace';
  return 'aurora';
}

function StyleSwitcher({ current = 'aurora' }: { current?: StyleKey }) {
  return (
    <div className="style-switcher" aria-label="Compare Wayve directions">
      <span className="mono" style={{ alignSelf: 'center', padding: '0 6px' }}>Direction</span>
      {(Object.keys(styleInfo) as StyleKey[]).map((key) => (
        <Link key={key} href={styleInfo[key].route} className={`style-pill ${current === key ? 'active' : ''}`} data-testid={`link-style-${key}`}>
          {styleInfo[key].label}
        </Link>
      ))}
    </div>
  );
}

function PublicNav({ current = 'aurora' }: { current?: StyleKey }) {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const links = [
    { href: '/jobs', label: 'Find work', icon: BriefcaseBusiness },
    { href: '/talent', label: 'Find talent', icon: Users },
    { href: '/marketplace', label: 'Marketplace', icon: Sparkles },
    { href: '/pricing', label: 'Pricing', icon: CircleDollarSign },
  ];
  return (
    <header className="topbar">
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20, position: 'relative' }}>
        <Logo />
        <nav className="nav" aria-label="Primary navigation">
          {links.map(({ href, label }) => <Link key={href} href={href} className={location === href ? 'active' : ''} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</Link>)}
        </nav>
        <div className="nav-actions">
          <Link href="/login" className="btn btn-ghost btn-small" data-testid="link-login"><LogIn size={14} /> Sign in</Link>
          <Link href="/dashboard" className="btn btn-primary btn-small" data-testid="link-dashboard">Open dashboard <ArrowRight size={14} /></Link>
          <button className="mobile-menu" onClick={() => setOpen((value) => !value)} aria-label="Toggle navigation" data-testid="button-mobile-menu">
            {open ? <X size={21} /> : <Menu size={21} />}
          </button>
        </div>
        <div className={`mobile-nav ${open ? 'open' : ''}`}>
          <StyleSwitcher current={current} />
          {links.map(({ href, label, icon: Icon }) => <Link onClick={() => setOpen(false)} key={href} href={href} data-testid={`link-mobile-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon size={16} /> {label}</Link>)}
          <Link onClick={() => setOpen(false)} href="/login" data-testid="link-mobile-login"><LogIn size={16} /> Sign in</Link>
        </div>
      </div>
    </header>
  );
}

function LandingFooter() {
  return (
    <footer className="footer container">
      <span>© 2025 Wayve, demo product surface.</span>
      <span className="mono">Your skills. Your future. Your wayve.</span>
    </footer>
  );
}

function HeroArt() {
  const artRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const handlePointerMove = (event: PointerEvent<HTMLDivElement>) => {
    const node = artRef.current;
    const card = cardRef.current;
    if (!node || !card) return;
    const bounds = node.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;
    card.style.setProperty('--tilt-x', `${(-y * 8).toFixed(2)}deg`);
    card.style.setProperty('--tilt-y', `${(x * 10).toFixed(2)}deg`);
    node.style.setProperty('--scene-x', `${(x * 22).toFixed(2)}px`);
    node.style.setProperty('--scene-y', `${(y * 18).toFixed(2)}px`);
  };
  const resetPointer = () => {
    cardRef.current?.style.setProperty('--tilt-x', '0deg');
    cardRef.current?.style.setProperty('--tilt-y', '0deg');
    artRef.current?.style.setProperty('--scene-x', '0px');
    artRef.current?.style.setProperty('--scene-y', '0px');
  };

  return (
    <div ref={artRef} className="hero-art" aria-label="Featured Wayve talent card" onPointerMove={handlePointerMove} onPointerLeave={resetPointer}>
      <Wayve3DScene />
      <div className="orbit one" /><div className="orbit two" /><span className="orbit-dot" />
      <div ref={cardRef} className="hero-card">
        <div className="card-top"><span className="mono">Featured profile</span><span style={{ fontSize: '.7rem' }}><span className="status-dot" />open to work</span></div>
        <div className="profile-line"><div className="profile-avatar">MC</div><div><h3>Maya Chen</h3><p>Product designer · Brooklyn</p></div></div>
        <div className="skill-row"><span className="skill">Product strategy</span><span className="skill">UX systems</span><span className="skill">Figma</span></div>
        <div className="rate"><span style={{ color: 'hsl(var(--muted-foreground))', fontSize: '.75rem' }}>Next opening</span><strong>$92 / hour</strong></div>
      </div>
    </div>
  );
}

function Landing({ style }: { style: StyleKey }) {
  const { message, notify } = useToastMessage();
  const label = styleInfo[style].label;
  return (
    <div className={`app style-${style}`}>
      <PublicNav current={style} />
      <main>
        <section className="hero">
          <EmberField />
          <div className="container hero-grid">
            <div>
              <p className="mono eyebrow">The way work finds you</p>
              <h1 className="display">Make your next move <span className="serif">feel like yours.</span></h1>
              <p className="hero-copy">Wayve brings ambitious people and thoughtful businesses together — for the role, project, or mentor that makes sense now.</p>
              <div className="hero-actions">
                <Link href="/jobs" className="btn btn-primary" data-testid="link-hero-find-work">Find your next role <ArrowRight size={16} /></Link>
                <Link href="/talent" className="btn btn-ghost" data-testid="link-hero-find-talent">Meet the talent <Users size={16} /></Link>
              </div>
              <div className="hero-note"><div className="avatar-stack"><span className="mini-avatar">MC</span><span className="mini-avatar">JO</span><span className="mini-avatar">AR</span></div> <span>18,400+ people making a move on Wayve</span></div>
            </div>
            <HeroArt />
          </div>
        </section>
        <RevealSection className="section section-tint">
          <div className="container">
            <div className="section-head"><h2>One place.<br /><span className="serif">More ways forward.</span></h2><p>Whether you are building your first portfolio or your fiftieth team, the right next step is closer than you think.</p></div>
            <div className="path-grid">
              {[
                { icon: BriefcaseBusiness, title: 'Find a role', text: 'Search work that respects your pace, craft, and point of view.' },
                { icon: Users, title: 'Find a person', text: 'Meet people who can add momentum — not just another name on a list.' },
                { icon: BookOpen, title: 'Learn a skill', text: 'Get unstuck with tutors and mentors who remember being new.' },
                { icon: Sparkles, title: 'Offer your craft', text: 'Turn the thing you do well into work people are looking for.' },
              ].map(({ icon: Icon, title, text }, index) => (
                <div className="path-card" key={title}><span className="path-index">0{index + 1} / {label}</span><h3><Icon size={18} strokeWidth={1.8} /> {title}</h3><p>{text}</p>{index === 0 && <Section3DObject kind="briefcase" />}{index === 2 && <Section3DObject kind="learning" />}</div>
              ))}
            </div>
          </div>
        </RevealSection>
        <RevealSection className="section">
          <div className="container quote"><div className="quote-mark">“</div><div className="quote-copy"><blockquote>“I stopped asking whether I was qualified and started asking whether the work was right.”</blockquote><cite>— Amina Okafor, brand strategist and Wayve member</cite></div></div>
        </RevealSection>
        <RevealSection className="section">
          <div className="container cta-band"><CareerGrowthObject /><h2>Somewhere between “looking” and “found” is your Wayve.</h2><button className="btn btn-primary" onClick={() => notify('Demo signup opened — no account created.')} data-testid="button-cta-join">Start exploring <ArrowRight size={16} /></button></div>
        </RevealSection>
      </main>
      <LandingFooter />
      <Toast message={message} />
    </div>
  );
}

function DesignPreview() {
  const [location] = useLocation();
  return (
    <div className="app style-aurora">
      <PublicNav current={styleFromPath(location)} />
      <main className="preview-page container">
        <div className="preview-head"><div><p className="mono eyebrow">Wayve / visual directions</p><h1 className="display">Four ways to see the next step.</h1><p>Same product, four distinct points of view. Pick the direction that makes Wayve feel most like a place ambitious people want to return to.</p></div><StyleSwitcher current={styleFromPath(location)} /></div>
        <div className="style-grid">
          <Link href="/style/aurora-glass" className="style-tile tile-aurora" data-testid="card-style-aurora"><span className="tile-stamp">01 · Aurora Glass</span><h2 className="display">Opportunities<br />in a softer light.</h2><div className="tile-footer"><p>Airy, optimistic, a little otherworldly. For people who want work to feel spacious.</p><ChevronRight size={27} /></div></Link>
          <Link href="/style/editorial" className="style-tile tile-editorial" data-testid="card-style-editorial"><span className="tile-stamp">02 · Editorial</span><h2 className="serif">Your work<br /><i>has a story.</i></h2><div className="tile-footer"><p>Warm, considered, and point-of-view led. A talent publication with a human pulse.</p><ChevronRight size={27} /></div></Link>
          <Link href="/style/trusted-career" className="style-tile tile-trusted" data-testid="card-style-trusted"><span className="tile-stamp">03 · Trusted Career</span><h2 className="display">The clear<br />way forward.</h2><div className="tile-footer"><p>Grounded, assured, and easy to scan. For decisions that deserve confidence.</p><ChevronRight size={27} /></div></Link>
          <Link href="/style/creator-marketplace" className="style-tile tile-creator" data-testid="card-style-creator"><span className="tile-stamp">04 · Creator Marketplace</span><h2 className="display">Put your<br />work out there.</h2><div className="tile-footer"><p>Expressive, energetic, and proudly personal. For makers who want to be found.</p><ChevronRight size={27} /></div></Link>
        </div>
      </main>
    </div>
  );
}

function SearchHeader({ title, intro, onSearch, query, placeholder }: { title: string; intro: string; onSearch: (value: string) => void; query: string; placeholder: string }) {
  return <><p className="mono eyebrow">Wayve / demo directory</p><h1 className="page-title display">{title}</h1><p className="page-intro">{intro}</p><div className="filter-row"><label className="searchbar"><Search size={17} /><input value={query} onChange={(event) => onSearch(event.target.value)} placeholder={placeholder} aria-label={placeholder} data-testid="input-search" /><kbd className="mono">⌘ K</kbd></label><button className="btn btn-soft btn-small" type="button" data-testid="button-filters"><SlidersHorizontal size={14} /> Filters</button></div></>;
}

function JobsPage() {
  const [query, setQuery] = useState('');
  const [type, setType] = useState('All types');
  const [saved, setSaved] = useState<string[]>([]);
  const { message, notify } = useToastMessage();
  const filtered = useMemo(() => jobs.filter((job) => `${job.title} ${job.company} ${job.location} ${job.skills.join(' ')}`.toLowerCase().includes(query.toLowerCase()) && (type === 'All types' || job.type === type)), [query, type]);
  const toggleSave = (id: string) => setSaved((items) => items.includes(id) ? items.filter((item) => item !== id) : [...items, id]);
  return <div className="app style-trusted-career"><PublicNav current="trusted-career" /><main className="page-shell container"><SearchHeader title="Work that moves you." intro="A deliberately small, carefully considered list of roles from teams who care about how work gets done." onSearch={setQuery} query={query} placeholder="Search roles, skills, or companies" /><div className="filter-row"><select className="select" value={type} onChange={(event) => setType(event.target.value)} aria-label="Filter by job type" data-testid="select-job-type"><option>All types</option><option>Full-time</option><option>Contract</option><option>Part-time</option></select><span className="mono" style={{ marginLeft: 'auto', color: 'hsl(var(--muted-foreground))' }}>{filtered.length} open roles · demo data</span></div><div className="results-grid">{filtered.length ? filtered.map((job) => <article className="job-card" key={job.id} data-testid={`card-job-${job.id}`}><div><div className="job-main"><div className="company-mark">{job.company.slice(0, 1)}</div><div><h3>{job.title}</h3><p>{job.company}</p></div></div><div className="job-meta"><span><MapPin size={12} style={{ verticalAlign: 'middle' }} /> {job.location}</span><span>{job.type}</span><span>Posted {job.postedAt}</span></div><div className="skill-row">{job.skills.map((skill) => <span className="skill" key={skill}>{skill}</span>)}</div></div><div className="job-side"><strong>{job.salary}</strong><button className={`icon-btn ${saved.includes(job.id) ? 'saved' : ''}`} onClick={() => { toggleSave(job.id); notify(saved.includes(job.id) ? 'Removed from saved roles.' : 'Role saved to your demo dashboard.'); }} aria-label={`Save ${job.title}`} data-testid={`button-save-job-${job.id}`}>{saved.includes(job.id) ? <BookmarkCheck size={17} /> : <Bookmark size={17} />}</button><button className="btn btn-primary btn-small" onClick={() => notify(`Demo application started for ${job.title}.`)} data-testid={`button-apply-job-${job.id}`}>Apply <ArrowRight size={13} /></button></div></article>) : <div className="empty"><Search size={26} /><h3>No roles in this orbit yet.</h3><p>Try a broader search or switch the work type.</p><button className="btn btn-ghost btn-small" onClick={() => { setQuery(''); setType('All types'); }} data-testid="button-reset-job-search">Reset search</button></div>}</div></main><Toast message={message} /></div>;
}

function TalentPage() {
  const [query, setQuery] = useState('');
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const { message, notify } = useToastMessage();
  const filtered = useMemo(() => talent.filter((person) => `${person.name} ${person.role} ${person.location} ${person.skills.join(' ')}`.toLowerCase().includes(query.toLowerCase()) && (!verifiedOnly || person.verified)), [query, verifiedOnly]);
  return <div className="app style-aurora"><PublicNav current="aurora" /><main className="page-shell container"><SearchHeader title="People with a point of view." intro="Find the specialist, collaborator, or teacher who can take the next version of your idea further." onSearch={setQuery} query={query} placeholder="Search people, skills, or locations" /><div className="filter-row"><button className={`btn btn-small ${verifiedOnly ? 'btn-primary' : 'btn-soft'}`} onClick={() => setVerifiedOnly((value) => !value)} data-testid="button-filter-verified"><ShieldCheck size={14} /> Verified only {verifiedOnly ? 'on' : 'off'}</button><span className="mono" style={{ marginLeft: 'auto', color: 'hsl(var(--muted-foreground))' }}>{filtered.length} people · demo profiles</span></div><div className="talent-grid">{filtered.length ? filtered.map((person) => <article className="talent-card" key={person.id} data-testid={`card-talent-${person.id}`}><div className="talent-top"><div className="talent-avatar">{person.name.split(' ').map((part) => part[0]).join('')}</div><div><h3>{person.name}</h3><p>{person.role}</p>{person.verified && <span className="verified"><BadgeCheck size={13} /> Verified profile</span>}</div></div><p style={{ marginTop: 18 }}><MapPin size={13} style={{ verticalAlign: 'middle' }} /> {person.location} · {person.availability}</p><div className="skill-row">{person.skills.map((skill) => <span className="skill" key={skill}>{skill}</span>)}</div><div className="talent-bottom"><strong>{person.rate}</strong><button className="btn btn-primary btn-small" onClick={() => notify(`Demo intro request sent to ${person.name}.`)} data-testid={`button-contact-talent-${person.id}`}><MessageCircle size={14} /> Say hello</button></div></article>) : <div className="empty" style={{ gridColumn: '1 / -1' }}><Users size={26} /><h3>No one matches that search.</h3><p>Try a skill, a role, or a different location.</p></div>}</div></main><Toast message={message} /></div>;
}

function MarketplacePage() {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All categories');
  const { message, notify } = useToastMessage();
  const filtered = useMemo(() => services.filter((service) => `${service.provider} ${service.title} ${service.category}`.toLowerCase().includes(query.toLowerCase()) && (category === 'All categories' || service.category === category)), [query, category]);
  return <div className="app style-creator-marketplace"><PublicNav current="creator-marketplace" /><main className="page-shell container"><SearchHeader title="Good work, ready to go." intro="A marketplace for the useful, the specific, and the beautifully made. Book a service or sell the thing you do best." onSearch={setQuery} query={query} placeholder="Search services or creators" /><div className="filter-row"><select className="select" value={category} onChange={(event) => setCategory(event.target.value)} aria-label="Filter by category" data-testid="select-service-category"><option>All categories</option><option>Design</option><option>Tutoring</option><option>Creative</option><option>Strategy</option><option>Development</option><option>Data</option></select><Link href="/dashboard" className="btn btn-primary btn-small" data-testid="link-sell-service"><PenLine size={14} /> List your service</Link></div><div className="service-grid">{filtered.length ? filtered.map((service) => <article className="service-card" key={service.id} data-testid={`card-service-${service.id}`}><div className="service-art" /><div className="service-content"><div className="mono service-category">{service.category} · {service.deliveryTime}</div><h3>{service.title}</h3><p>by {service.provider}</p><div className="service-foot"><span className="price">{service.price} <span style={{ color: 'hsl(var(--muted-foreground))', fontFamily: 'var(--app-font-sans)', fontSize: '.7rem' }}>· <Star size={11} fill="currentColor" style={{ verticalAlign: 'middle' }} /> {service.rating}</span></span><button className="btn btn-primary btn-small" onClick={() => notify(`Demo booking started for ${service.title}.`)} data-testid={`button-book-service-${service.id}`}>Book <ArrowRight size={13} /></button></div></div></article>) : <div className="empty" style={{ gridColumn: '1 / -1' }}><Sparkles size={26} /><h3>That service is still being made.</h3><p>Try a different category or search phrase.</p></div>}</div></main><Toast message={message} /></div>;
}

function PricingPage() {
  const [annual, setAnnual] = useState(true);
  const { message, notify } = useToastMessage();
  const plans = [
    { name: 'Explore', note: 'For making your first move', monthly: '$0', annual: '$0', features: ['Browse jobs and talent', 'Save up to 10 roles', 'Join the Wayve community'] },
    { name: 'Wayve Plus', note: 'For momentum that compounds', monthly: '$18', annual: '$14', features: ['Unlimited saved searches', 'Profile insights', 'Priority introductions'], featured: true },
    { name: 'For teams', note: 'For people hiring with care', monthly: '$149', annual: '$119', features: ['Unlimited role listings', 'Shortlist collaborators', 'Dedicated talent support'] },
  ];
  return <div className="app style-editorial"><PublicNav current="editorial" /><main className="page-shell container"><div className="pricing-head"><p className="mono eyebrow">Wayve / simple by design</p><h1 className="serif">A better way<br /><i>to begin.</i></h1><p className="page-intro" style={{ margin: '0 auto' }}>Start with what you need. Stay for what you find. No lock-in, no hidden conditions.</p><div className="pricing-toggle"><button className={annual ? 'active' : ''} onClick={() => setAnnual(true)} data-testid="button-pricing-annual">Annual <span className="mono">save 22%</span></button><button className={!annual ? 'active' : ''} onClick={() => setAnnual(false)} data-testid="button-pricing-monthly">Monthly</button></div></div><div className="price-grid">{plans.map((plan) => <article key={plan.name} className={`price-card ${plan.featured ? 'featured' : ''}`} data-testid={`card-pricing-${plan.name.toLowerCase().replace(' ', '-')}`}><span className="mono">{plan.featured ? 'Most chosen' : plan.name}</span><h3>{plan.note}</h3><div className="amount">{annual ? plan.annual : plan.monthly}<small style={{ fontFamily: 'var(--app-font-sans)', fontSize: '.78rem', color: 'inherit', opacity: .7 }}>{plan.name === 'Explore' ? ' / forever' : ' / month'}</small></div><ul>{plan.features.map((feature) => <li key={feature}><CheckCircle2 size={15} /> {feature}</li>)}</ul><button className={`btn ${plan.featured ? 'btn-primary' : 'btn-ghost'}`} onClick={() => notify(`${plan.name} is a demo plan — no payment taken.`)} data-testid={`button-choose-${plan.name.toLowerCase().replace(' ', '-')}`}>Choose {plan.name} <ArrowRight size={14} /></button></article>)}</div></main><Toast message={message} /></div>;
}

function LoginPage() {
  const [, setLocation] = useLocation();
  const { message, notify } = useToastMessage();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);
    window.setTimeout(() => { setLoading(false); setLocation('/dashboard'); }, 650);
  };
  return <div className="app style-trusted-career auth-page"><aside className="auth-aside"><Logo /><div><p className="mono">A place for your next chapter</p><h1 className="serif">Come as you are. Leave with a wayve.</h1><p>Sign in to pick up where you left off — saved roles, messages, and the work you are ready to share.</p></div><span className="mono">Demo access · private behavior not connected</span></aside><main className="auth-form-wrap"><form className="auth-form" onSubmit={submit}><span className="mono eyebrow">Welcome back</span><h2>Find your way in.</h2><p>Use any email to preview the signed-in experience.</p><label className="form-label" htmlFor="email">Email address</label><input className="form-input" id="email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" required data-testid="input-email" /><label className="form-label" htmlFor="password">Password</label><input className="form-input" id="password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 8 characters" required minLength={8} data-testid="input-password" /><button className="btn btn-primary" type="submit" disabled={loading} data-testid="button-sign-in">{loading ? 'Opening your dashboard…' : 'Sign in to Wayve'} <ArrowRight size={15} /></button><div className="demo-notice"><ShieldCheck size={14} style={{ verticalAlign: 'middle', marginRight: 6 }} /> This is a demo flow. No account, password, or payment is stored. <button type="button" onClick={() => notify('Password recovery is represented in this demo.')} style={{ border: 0, padding: 0, background: 'transparent', textDecoration: 'underline', color: 'inherit' }} data-testid="button-forgot-password">Forgot password?</button></div></form><Toast message={message} /></main></div>;
}

function DashboardPage() {
  const [, setLocation] = useLocation();
  const [tab, setTab] = useState('Overview');
  const [menuOpen, setMenuOpen] = useState(false);
  const tabs = ['Overview', 'Saved roles', 'Applications', 'Messages'];
  const activity = [
    { icon: Eye, text: 'Your profile was viewed by Pollen Studio.', time: 'Today · 9:41 AM' },
    { icon: BookmarkCheck, text: 'You saved Senior Product Designer.', time: 'Yesterday · 4:12 PM' },
    { icon: MessageCircle, text: 'Amina sent you a new introduction.', time: 'Tuesday · 11:06 AM' },
  ];
  return <div className="app style-trusted-career dashboard"><aside className="dash-sidebar"><Logo /><nav className="dash-nav" aria-label="Dashboard navigation">{[{ label: 'Overview', icon: LayoutDashboard }, { label: 'Saved roles', icon: Bookmark }, { label: 'Applications', icon: Send }, { label: 'Messages', icon: MessageCircle }].map(({ label, icon: Icon }) => <button key={label} onClick={() => setTab(label)} className={tab === label ? 'active' : ''} data-testid={`button-dashboard-${label.toLowerCase().replace(' ', '-')}`}><Icon size={16} /> {label}</button>)}</nav><div className="dash-bottom dash-nav"><Link href="/jobs" data-testid="link-dashboard-find-work"><Compass size={16} /> Find more work</Link><button onClick={() => setLocation('/')} data-testid="button-dashboard-sign-out"><LogIn size={16} /> Exit demo</button></div></aside><main className="dash-main"><div className="dash-top"><div><span className="mono eyebrow">Wayve / demo dashboard</span><h1>Good morning, Alex.</h1><p>Here is the useful stuff, without the noise.</p></div><div className="dash-profile"><button className="icon-btn" onClick={() => setMenuOpen((value) => !value)} aria-label="Open notifications" data-testid="button-notifications"><Bell size={17} /></button><div className="dash-avatar">AR</div>{menuOpen && <div style={{ position: 'absolute', right: 40, top: 80, background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 10, padding: 13, fontSize: '.75rem' }}>You are all caught up.</div>}</div></div><div className="dash-tab">{tabs.map((item) => <button key={item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)} data-testid={`tab-dashboard-${item.toLowerCase().replace(' ', '-')}`}>{item}</button>)}</div>{tab === 'Overview' ? <><div className="stat-grid">{[{ label: 'Profile views', value: '247', change: '+18.4%' }, { label: 'Saved roles', value: '12', change: '3 closing soon' }, { label: 'Applications', value: '04', change: '1 in review' }, { label: 'This month', value: '$1,840', change: '+$420 earned' }].map((stat) => <div className="stat" key={stat.label} data-testid={`stat-${stat.label.toLowerCase().replace(' ', '-')}`}><p>{stat.label}</p><strong>{stat.value}</strong><small>{stat.change}</small></div>)}</div><div className="dash-columns"><section className="dash-panel"><div className="panel-head"><h2>Recent activity</h2><button className="icon-btn" aria-label="More activity options" onClick={() => setMenuOpen(true)} data-testid="button-more-activity"><Zap size={15} /></button></div><div className="activity">{activity.map(({ icon: Icon, text, time }) => <div className="activity-item" key={text}><div className="activity-icon"><Icon size={14} /></div><p>{text}<time>{time}</time></p></div>)}</div></section><section className="dash-panel"><div className="panel-head"><h2>Profile strength</h2><TrendingUp size={17} color="hsl(var(--primary))" /></div><div className="completion"><div className="progress-ring"><span>78%</span></div><p style={{ fontSize: '.78rem', lineHeight: 1.5, color: 'hsl(var(--muted-foreground))' }}>You are close to being <strong style={{ color: 'hsl(var(--foreground))' }}>ready to be found.</strong></p></div><button className="btn btn-primary btn-small" style={{ marginTop: 24 }} onClick={() => setTab('Messages')} data-testid="button-complete-profile">Complete profile <ArrowRight size={13} /></button></section></div></> : <div className="empty"><FileText size={26} /><h3>{tab} are ready for the next action.</h3><p>This signed-in demo keeps the flow clear. Connect your account to see private {tab.toLowerCase()}.</p><button className="btn btn-primary btn-small" onClick={() => setLocation('/jobs')} data-testid="button-dashboard-continue">Continue exploring <ArrowRight size={13} /></button></div>}</main></div>;
}

function StyleRoute() {
  const { style } = useParams<{ style: StyleLandingKey }>();
  const key: StyleKey = style === 'editorial' ? 'editorial' : style === 'trusted-career' ? 'trusted-career' : style === 'creator-marketplace' ? 'creator-marketplace' : 'aurora';
  return <Landing style={key} />;
}

function Router() {
  return <ErrorBoundary><Switch><Route path="/" component={() => <Landing style="aurora" />} /><Route path="/design-preview" component={DesignPreview} /><Route path="/style/:style" component={StyleRoute} /><Route path="/jobs" component={JobsPage} /><Route path="/talent" component={TalentPage} /><Route path="/marketplace" component={MarketplacePage} /><Route path="/pricing" component={PricingPage} /><Route path="/login" component={LoginPage} /><Route path="/dashboard" component={DashboardPage} /><Route component={NotFound} /></Switch></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;